package br.edu.unoesc

    //fun calcularparcelas(calculaparcelas: Array<CalculaPar>):Double{
    //    return calcularparcelas().map(CalculaPar::getdivideParcelas).sum()
    //}